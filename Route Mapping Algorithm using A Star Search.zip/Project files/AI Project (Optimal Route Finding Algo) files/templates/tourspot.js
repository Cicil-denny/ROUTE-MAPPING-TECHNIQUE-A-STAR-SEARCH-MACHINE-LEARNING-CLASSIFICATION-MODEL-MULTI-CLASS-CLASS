function touristSpot() {
    inputValue = document.getElementById("opt").value;
                
                if (inputValue = "churches") {
                    alert(" Poor Choice ");
                } else if (inputValue = "resorts") {
                    alert(" Average Choice ");
                } else if (inputValue = "beaches") {
                    alert(" Average Choice ");
                } else if (inputValue = "parks") {
                    alert(" Average Choice ");
                } else if (inputValue = "theaters") {
                    alert(" Average Choice ");
                } else if (inputValue = "museums") {
                    alert(" Average Choice ");
                } else if (inputValue = "malls") {
                    alert(" Good Choice ");
                } else if (inputValue = "zoo") {
                    alert(" Average Choice ");
                } else if (inputValue = "restaurants") {
                    alert(" Good Choice ");
                } else if (inputValue = "pubs") {
                    alert(" Average Choice ");
                } else if (inputValue = "localservices") {
                    alert(" Average Choice ");
                } else if (inputValue = "burgershops") {
                    alert(" Average Choice ");
                } else if (inputValue = "hotels") {
                    alert(" Average Choice ");
                } else if (inputValue = "juicebars") {
                    alert(" Average Choice ");
                } else if (inputValue = "artgalleries") {
                    alert(" Average Choice ");
                } else if (inputValue = "danceclubs") {
                    alert(" Poor Choice ");
                } else if (inputValue = "swimmingpools") {
                    alert(" Terrible Choice ");
                } else if (inputValue = "gyms") {
                    alert(" Terrible Choice ");
                } else if (inputValue = "bakeries") {
                    alert(" Terrible Choice ");
                } else if (inputValue = "beauty&spa") {
                    alert(" Poor Choice ");
                } else if (inputValue = "cafe") {
                    alert(" Poor Choice ");
                } else if (inputValue = "viewpoints") {
                    alert(" Poor Choice ");
                } else if (inputValue = "monuments") {
                    alert(" Poor Choice ");
                } else if (inputValue = "garden") {
                    alert(" Poor Choice ");
                } else {
                    alert("Please Fill in everything correctly");
                }
            
            }