from flask import *  
  
app = Flask(__name__)  

@app.route('/error')  
def error():  
    return "<center><p><strong> Enter the correct password </strong></p></center>"  
 
@app.route('/')  
def login():  
    return render_template("login.html")  
 
@app.route('/success',methods = ['POST'])  
def success():  
    if request.method == "POST":  
        email = request.form['email']  
        password = request.form['pass']  
      
    if (password == "123"):  
        resp = make_response(render_template('success.html'))  
        resp.set_cookie('email', email)  
        return resp

    else:  
        return redirect(url_for('error'))  
 
@app.route('/viewprofile')  
def profile():  
    email = request.cookies.get('email')  
    resp = make_response(render_template('profile.html', name = email))  
    return resp

@app.route('/viewhome')
def home():
    return render_template("home.html")

@app.route('/viewsample')
def sample():
    return render_template("sample.html")

#@app.route('/viewimage1')
#def image1():
#    return render_template(r"C:\Users\cicil\OneDrive\Desktop\4th Semester Programming\Python Codes\CSE1014 - J Component\templates\img.png")

#@app.route('/viewimage2')
#def image2():
#    return render_template(r"C:\Users\cicil\OneDrive\Desktop\4th Semester Programming\Python Codes\CSE1014 - J Component\templates\img2.jpg")

@app.route('/viewspotRecommendation')
def spotRecommendation():
    return render_template("spot.html")

@app.route('/viewroute')
def route():
    return render_template("sam.html")


if __name__ == "__main__":  
    app.run(debug = True) 